# CoC Tutorial Overlay MVP (Android)

Prototype Android overlay for guided Clash of Clans learning. It displays an instruction card, a decorative arrow, a **Lanjut** button, and a TH1–TH3 tutorial sequence.

## What the automatic cloud build does
- Every push/commit to `main` starts GitHub Actions automatically.
- You can also start a build manually from **Actions → Build Android APK → Run workflow**.
- A successful run uploads `CoCOverlayMVP-debug-apk` as an artifact for 14 days.
- No GitHub secret or paid API key is required for this basic build workflow.

## Important limits
- This is a **manual guidance overlay**, not a game bot. It does not tap, read, modify, or automate Clash of Clans.
- The arrow is decorative and is **not yet positioned over a recognized game control**. Automatic screen recognition and context-aware arrows are future phases.
- Supercell can change building availability and game mechanics; treat the tutorial as general beginner guidance.
- Android may show a foreground-service notification. Overlay permission must be granted manually.
- This prototype has not been device-tested. Build and install at your own risk; use a test device if possible.

## Phone-first setup (one-time)
1. Download and extract this ZIP on your Android phone using a file manager that can extract ZIP files.
2. Open GitHub in your browser and sign in.
3. Create a new repository named `CoCOverlayMVP`. For easiest first setup, choose **Public**; do not add a README, license, or `.gitignore` because this ZIP already contains those project files.
4. Upload the **contents** of the extracted project into the repository root, not the ZIP file itself. Make sure `.github/workflows/build-apk.yml` is uploaded too. If the mobile web uploader does not preserve the `.github` folder, use GitHub Codespaces or another cloud IDE to upload/commit the project.
5. Commit all files to the `main` branch. This first commit should trigger the workflow automatically.
6. Open the repository's **Actions** tab. Select the newest **Build Android APK** run.
7. Wait for the green success mark. Scroll to **Artifacts** and download `CoCOverlayMVP-debug-apk`. Extract that downloaded artifact ZIP to get `app-debug.apk`.
8. On Android, allow installing unknown apps for the app used to download the APK, then install it. Only install APKs you built and trust.

## Future updates (automatic)
After setup, every time you commit a code change to `main`, GitHub Actions builds a fresh APK automatically. You only need to download the new artifact from that run when you want to test it. No manual build command is needed.

## First run
1. Open **CoC Tutorial Overlay**.
2. Tap **1. Aktifkan izin overlay** and allow display over other apps.
3. Return to the app and tap **2. Tampilkan kartu tutorial**.
4. Open Clash of Clans. The card and decorative arrow should remain on top if the Android device permits it.
5. Tap **Lanjut →** to step through TH1–TH3. Tap **Tutup** or return to the app and stop the service to hide it.

## Project structure
- `app/src/main/java/id/coc/overlaymvp/MainActivity.kt`: permission and start/stop controls.
- `OverlayService.kt`: floating card and arrow.
- `TutorialStep.kt`: TH1–TH3 steps.
- `.github/workflows/build-apk.yml`: automatic cloud build workflow.

## Troubleshooting
- **No Actions run:** check that the workflow file exists at exactly `.github/workflows/build-apk.yml` on `main`; check repository Actions are enabled.
- **Build fails:** open the failed run, expand the red step, and copy the last 30–50 lines of the log. Do not share access tokens or secrets.
- **Artifact missing:** the APK artifact is only uploaded after a successful build.
- **Overlay doesn't appear:** confirm the Android “display over other apps” permission and check whether the OS restricts foreground services.

## Next MVP improvements
1. Test installation and overlay on the actual phone.
2. Make the card draggable and add a compact/minimize control.
3. Add a Town Hall selector and step checklist.
4. Only after the overlay works reliably, add explicit user-approved screen capture and basic screen-state recognition.
