package id.coc.overlaymvp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: View? = null
    private var index = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(17, buildNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showStep()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay == null) showStep()
        return START_STICKY
    }

    private fun showStep() {
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val density = resources.displayMetrics.density
        val pad = (12 * density).toInt()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.rgb(25, 33, 44))
            elevation = 12f * density
        }

        val header = TextView(this).apply {
            text = "⬆  PANDUAN CLASH OF CLANS"
            textSize = 13f
            setTextColor(Color.rgb(150, 220, 255))
        }
        val title = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, pad / 2, 0, pad / 2)
        }
        val instruction = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
        }
        val hint = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, pad / 2, 0, pad / 2)
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val close = Button(this).apply {
            text = "Tutup"
            setOnClickListener { stopSelf() }
        }
        val next = Button(this).apply {
            text = "Lanjut →"
            setOnClickListener {
                index = (index + 1) % TutorialData.steps.size
                updateTexts(title, instruction, hint)
            }
        }
        buttons.addView(close)
        buttons.addView(next)
        card.addView(header)
        card.addView(title)
        card.addView(instruction)
        card.addView(hint)
        card.addView(buttons)

        // A non-touchable decorative arrow so it does not block game controls.
        val arrow = TextView(this).apply {
            text = "⬇"
            textSize = 42f
            setTextColor(Color.YELLOW)
            gravity = Gravity.CENTER
            setShadowLayer(5f, 0f, 0f, Color.BLACK)
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val cardParams = WindowManager.LayoutParams(
            (320 * density).toInt().coerceAtMost((resources.displayMetrics.widthPixels * 0.9f).toInt()),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (12 * density).toInt()
            y = (80 * density).toInt()
        }
        val arrowParams = WindowManager.LayoutParams(
            (60 * density).toInt(), (60 * density).toInt(),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (resources.displayMetrics.heightPixels * 0.48f).toInt()
        }

        try {
            windowManager.addView(card, cardParams)
            windowManager.addView(arrow, arrowParams)
            overlay = card
            // Keep a reference to the decorative arrow and remove it with the card.
            card.tag = arrow
            updateTexts(title, instruction, hint)
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun updateTexts(title: TextView, instruction: TextView, hint: TextView) {
        val step = TutorialData.steps[index]
        title.text = step.title
        instruction.text = step.instruction
        hint.text = step.hint
    }

    override fun onDestroy() {
        try {
            val card = overlay
            if (card != null) {
                val arrow = card.tag as? View
                if (arrow != null) windowManager.removeView(arrow)
                windowManager.removeView(card)
            }
        } catch (_: Exception) { }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("coc_overlay", "Tutorial overlay", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "coc_overlay") else @Suppress("DEPRECATION") Notification.Builder(this)
        return builder
            .setContentTitle("CoC Tutorial Overlay aktif")
            .setContentText("Kartu panduan tampil di atas game. Ketuk Tutup untuk berhenti.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }
}
