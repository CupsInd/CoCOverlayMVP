package id.coc.overlaymvp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "CoC Tutorial Overlay · MVP"
            textSize = 24f
        }
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad / 2, 0, pad)
        }
        val permission = Button(this).apply {
            text = "1. Aktifkan izin overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    Toast.makeText(this@MainActivity, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val start = Button(this).apply {
            text = "2. Tampilkan kartu tutorial"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Aktifkan izin overlay dulu", Toast.LENGTH_LONG).show()
                } else {
                    val intent = Intent(this@MainActivity, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
                    Toast.makeText(this@MainActivity, "Overlay dimulai", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "3. Hentikan overlay"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        val note = TextView(this).apply {
            text = "\nVersi awal: kartu instruksi, panah dekoratif, tombol Lanjut, dan tutorial TH1–TH3. Belum mengenali layar game otomatis."
            textSize = 14f
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(permission, match())
        layout.addView(start, match())
        layout.addView(stop, match())
        layout.addView(note)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            status.text = if (Settings.canDrawOverlays(this)) "Status izin: AKTIF" else "Status izin: belum aktif"
        }
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = (8 * resources.displayMetrics.density).toInt() }
}
