package id.coc.overlaymvp

data class TutorialStep(
    val townHall: Int,
    val title: String,
    val instruction: String,
    val hint: String
)

object TutorialData {
    // General beginner guidance. Game balance and available buildings can change with updates.
    val steps = listOf(
        TutorialStep(1, "TH1 · Kenali desa", "Buka desa dan lihat bangunan yang tersedia. Selesaikan tutorial bawaan game terlebih dahulu.", "Jangan gunakan aplikasi ini untuk auto-tap; overlay hanya memberi panduan."),
        TutorialStep(1, "TH1 · Selesaikan tutorial", "Ikuti instruksi dalam game sampai fitur dasar terbuka. Perhatikan ikon panah atau penanda dari game.", "Jika kartu menutupi tombol game, geser kartu ke tepi layar."),
        TutorialStep(2, "TH2 · Bangun yang tersedia", "Bangun semua bangunan yang tersedia dan tingkatkan bangunan ofensif yang bisa ditingkatkan.", "Ketersediaan bangunan mengikuti progres akun dan versi game."),
        TutorialStep(2, "TH2 · Kumpulkan sumber daya", "Serang target mudah dengan pasukan yang tersedia, lalu gunakan Gold dan Elixir untuk pembangunan.", "Pilih target yang terlihat mudah; jangan habiskan semua waktu mencari lawan."),
        TutorialStep(3, "TH3 · Prioritas ofensif", "Prioritaskan Army Camp, Barracks, dan Laboratory jika sudah tersedia. Tingkatkan pasukan utama di Laboratory.", "Urutan dan nama bangunan dapat berbeda sesuai versi dan progres akun."),
        TutorialStep(3, "TH3 · Siapkan langkah berikutnya", "Pastikan bangunan penting yang tersedia sudah dibangun, lalu pertimbangkan Town Hall berikutnya jika ofensif sudah siap.", "Tidak perlu menunggu setiap bangunan dekoratif selesai sebelum maju.")
    )
}
